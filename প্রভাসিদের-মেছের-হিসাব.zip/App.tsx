
import React, { useState, useEffect, useMemo } from 'react';
import { Member, Expense, ExpenseType, MessSummary } from './types';
import { calculateMessSummary, formatCurrency } from './utils/calculations';
import Layout from './components/Layout';
import { geminiService } from './services/geminiService';

const STORAGE_KEYS = {
  MEMBERS: 'mess_members_v1',
  EXPENSES: 'mess_expenses_v1'
};

const INITIAL_MEMBERS: Member[] = [
  { id: '1', name: 'বিল্লাল', avatar: 'https://picsum.photos/seed/billal/100', joinDate: 0 },
  { id: '2', name: 'জামাল', avatar: 'https://picsum.photos/seed/jamal/100', joinDate: 0 },
  { id: '3', name: 'আব্দুর', avatar: 'https://picsum.photos/seed/abdur/100', joinDate: 0 },
];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  
  const [members, setMembers] = useState<Member[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MEMBERS);
    return saved ? JSON.parse(saved) : INITIAL_MEMBERS;
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.EXPENSES);
    return saved ? JSON.parse(saved) : [];
  });

  const [aiInsight, setAiInsight] = useState<string>('হিসাব চেক করা হচ্ছে...');
  
  const [newMemberName, setNewMemberName] = useState('');
  const [expenseDesc, setExpenseDesc] = useState('');
  const [expenseAmount, setExpenseAmount] = useState('');
  const [expenseType, setExpenseType] = useState<ExpenseType>(ExpenseType.SHARED);
  const [payerId, setPayerId] = useState(members[0]?.id || '');
  const [targetId, setTargetId] = useState('');

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(members));
  }, [members]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(expenses));
  }, [expenses]);

  const summary = useMemo(() => calculateMessSummary(members, expenses), [members, expenses]);

  useEffect(() => {
    const fetchInsight = async () => {
      if (expenses.length > 0) {
        const insight = await geminiService.getSmartInsight(summary);
        setAiInsight(insight);
      } else {
        setAiInsight("ম্যাচের কোনো খরচ এখনও যোগ করা হয়নি।");
      }
    };
    fetchInsight();
  }, [summary, expenses.length]);

  const addMember = () => {
    if (!newMemberName.trim()) return;
    const now = Date.now();
    const newMember: Member = {
      id: now.toString(),
      name: newMemberName,
      avatar: `https://picsum.photos/seed/${newMemberName}/100`,
      joinDate: now, // নতুন মেম্বার যোগ হওয়ার সময় সেভ করা হচ্ছে
    };
    setMembers([...members, newMember]);
    setNewMemberName('');
    if (!payerId) setPayerId(newMember.id);
  };

  const removeMember = (id: string) => {
    const member = members.find(m => m.id === id);
    if (!member) return;

    if (window.confirm(`${member.name}-কে কি সত্যি ডিলিট করতে চান?`)) {
      const updatedMembers = members.filter(m => m.id !== id);
      setMembers(updatedMembers);
      if (payerId === id) setPayerId(updatedMembers[0]?.id || '');
    }
  };

  const removeExpense = (id: string) => {
    if (window.confirm("এই খরচের হিসাবটি ডিলিট করতে চান?")) {
      setExpenses(expenses.filter(e => e.id !== id));
    }
  };

  const addExpense = () => {
    const amount = parseFloat(expenseAmount);
    if (!expenseDesc || isNaN(amount) || !payerId) {
      alert("দয়া করে সব তথ্য সঠিক ভাবে পূরণ করুন।");
      return;
    }

    const newExpense: Expense = {
      id: Date.now().toString(),
      description: expenseDesc,
      amount,
      type: expenseType,
      payerId,
      targetMemberId: expenseType === ExpenseType.PERSONAL ? targetId : undefined,
      date: Date.now(),
    };

    setExpenses([newExpense, ...expenses]);
    setExpenseDesc('');
    setExpenseAmount('');
    setActiveTab('dashboard');
  };

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Overview */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
        <h2 className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] mb-4">ম্যাচের বর্তমান অবস্থা</h2>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-indigo-50 p-4 rounded-2xl border border-indigo-100">
            <p className="text-indigo-600 text-xs font-bold mb-1">মোট বাজার খরচ</p>
            <p className="text-slate-900 text-xl font-black">{formatCurrency(summary.totalSharedExpense)}</p>
          </div>
          <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100">
            <p className="text-emerald-600 text-xs font-bold mb-1">জনপ্রতি গড় ভাগ</p>
            <p className="text-slate-900 text-xl font-black">{formatCurrency(summary.averagePerPerson)}</p>
          </div>
        </div>
        
        <div className="mt-5 p-4 bg-slate-50 rounded-2xl border border-slate-200 flex gap-3 items-start">
          <div className="text-xl">🤖</div>
          <p className="text-[11px] text-slate-600 leading-relaxed font-medium">{aiInsight}</p>
        </div>
      </div>

      {/* Member List - Total Bill */}
      <div className="space-y-3">
        <div className="flex justify-between items-center px-2">
          <h2 className="text-slate-900 font-black text-lg">সদস্যদের বিল</h2>
          <button onClick={() => setActiveTab('summary')} className="text-indigo-600 text-xs font-bold bg-indigo-50 px-3 py-1.5 rounded-full">মেম্বার যোগ+</button>
        </div>
        
        {summary.memberBalances.length === 0 ? (
          <div className="bg-white rounded-3xl p-10 text-center border border-slate-100 shadow-sm">
            <p className="text-slate-400 font-medium font-bold">মেম্বার যোগ করুন</p>
          </div>
        ) : (
          summary.memberBalances.map((mb) => (
            <div key={mb.member.id} className="bg-white rounded-2xl p-4 flex items-center justify-between shadow-sm border border-slate-100 transition-all group">
              <div className="flex items-center gap-3">
                <img src={mb.member.avatar} alt={mb.member.name} className="w-12 h-12 rounded-full border-2 border-slate-100 shadow-sm" />
                <div>
                  <p className="font-bold text-slate-900">{mb.member.name}</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">
                    ম্যাচ ভাগ: {formatCurrency(mb.sharedShare)}
                  </p>
                </div>
              </div>
              <div className="text-right flex items-center gap-4">
                <div>
                  <p className="text-lg font-black text-slate-900">
                    {formatCurrency(mb.netBalance)}
                  </p>
                  <p className="text-[9px] text-rose-500 font-bold">ব্যক্তিগত: {formatCurrency(mb.personalTotal)}</p>
                </div>
                <button 
                  onClick={() => removeMember(mb.member.id)} 
                  className="p-2 text-rose-100 hover:text-rose-500 transition-colors bg-rose-50 rounded-xl"
                  title="ডিলিট"
                >
                   <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );

  const renderAddExpense = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
        <h2 className="text-xl font-black text-slate-900 mb-6 text-center">খরচ লিখুন</h2>
        
        <div className="space-y-5">
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 tracking-widest">বিবরণ</label>
            <input 
              type="text" 
              placeholder="কি কিনেছেন?" 
              className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-4 focus:ring-2 focus:ring-indigo-500 outline-none font-medium text-slate-700 transition-all"
              value={expenseDesc}
              onChange={(e) => setExpenseDesc(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 tracking-widest">পরিমাণ (SR)</label>
              <input 
                type="number" 
                placeholder="0.00" 
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-4 focus:ring-2 focus:ring-indigo-500 outline-none font-black text-slate-700 transition-all"
                value={expenseAmount}
                onChange={(e) => setExpenseAmount(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 tracking-widest">টাকা দিয়েছেন</label>
              <select 
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-4 focus:ring-2 focus:ring-indigo-500 outline-none appearance-none font-bold text-slate-700"
                value={payerId}
                onChange={(e) => setPayerId(e.target.value)}
              >
                {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-3 tracking-widest">খরচের ধরন</label>
            <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={() => setExpenseType(ExpenseType.SHARED)}
                className={`py-4 px-4 rounded-2xl text-xs font-black border-2 transition-all ${expenseType === ExpenseType.SHARED ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-100' : 'bg-white text-slate-400 border-slate-100 hover:border-indigo-100'}`}
              >
                🤝 ম্যাচের বাজার
              </button>
              <button 
                onClick={() => setExpenseType(ExpenseType.PERSONAL)}
                className={`py-4 px-4 rounded-2xl text-xs font-black border-2 transition-all ${expenseType === ExpenseType.PERSONAL ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-100' : 'bg-white text-slate-400 border-slate-100 hover:border-indigo-100'}`}
              >
                👤 ব্যক্তিগত খরচ
              </button>
            </div>
          </div>

          {expenseType === ExpenseType.PERSONAL && (
            <div className="animate-fade-in bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100">
              <label className="block text-[10px] font-black text-indigo-400 uppercase mb-2 tracking-widest">কার ব্যক্তিগত খরচ?</label>
              <select 
                className="w-full bg-white border border-indigo-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none appearance-none font-bold text-slate-700"
                value={targetId}
                onChange={(e) => setTargetId(e.target.value)}
              >
                <option value="">সিলেক্ট করুন</option>
                {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
              </select>
            </div>
          )}

          <button 
            onClick={addExpense}
            className="w-full bg-indigo-600 text-white font-black py-5 rounded-3xl mt-4 shadow-xl shadow-indigo-200 hover:bg-indigo-700 active:scale-95 transition-all text-lg"
          >
            খরচ যোগ করুন
          </button>
        </div>
      </div>
    </div>
  );

  const renderHistory = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center px-2">
        <h2 className="text-xl font-black text-slate-900">খরচের খাতা</h2>
        <span className="text-[10px] font-black text-slate-500 bg-slate-100 px-3 py-1.5 rounded-full">{expenses.length} এন্ট্রি</span>
      </div>
      {expenses.length === 0 ? (
        <div className="bg-white rounded-3xl p-16 text-center border-2 border-dashed border-slate-200">
          <p className="text-slate-400 font-bold">খাতা খালি।</p>
        </div>
      ) : (
        expenses.map(exp => {
          const payer = members.find(m => m.id === exp.payerId);
          const target = exp.targetMemberId ? members.find(m => m.id === exp.targetMemberId) : null;
          return (
            <div key={exp.id} className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 flex justify-between items-center">
              <div className="flex gap-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl shadow-sm ${exp.type === ExpenseType.SHARED ? 'bg-indigo-50 text-indigo-500' : 'bg-rose-50 text-rose-500'}`}>
                  {exp.type === ExpenseType.SHARED ? '📦' : '👤'}
                </div>
                <div>
                  <p className="font-black text-slate-800">{exp.description}</p>
                  <p className="text-[10px] text-slate-400 font-bold tracking-tight">
                    {payer?.name} দিয়েছেন {target ? `• ${target.name}-এর জন্য` : '• ম্যাচে'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="font-black text-slate-900 text-lg">{formatCurrency(exp.amount)}</p>
                  <p className="text-[10px] text-slate-400 font-bold">{new Date(exp.date).toLocaleDateString('bn-BD')}</p>
                </div>
                <button 
                  onClick={() => removeExpense(exp.id)} 
                  className="p-2 text-rose-100 hover:text-rose-500 transition-colors bg-rose-50 rounded-xl"
                  title="ডিলিট"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                </button>
              </div>
            </div>
          );
        })
      )}
    </div>
  );

  const renderSummary = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
        <h3 className="font-black text-slate-900 mb-4 flex justify-between items-center text-lg">
          মেম্বার লিস্ট
          <span className="text-[10px] bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full">{members.length} জন</span>
        </h3>
        <div className="flex gap-2 mb-6">
          <input 
            type="text" 
            placeholder="নতুন মেম্বারের নাম" 
            className="flex-1 bg-slate-50 border border-slate-200 rounded-2xl px-4 py-4 outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
            value={newMemberName}
            onChange={(e) => setNewMemberName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addMember()}
          />
          <button 
            onClick={addMember} 
            className="bg-indigo-600 text-white px-6 py-4 rounded-2xl font-black shadow-lg shadow-indigo-100"
          >
            যোগ
          </button>
        </div>
        
        <div className="space-y-3">
          {members.map(m => (
            <div key={m.id} className="flex justify-between items-center p-4 bg-slate-50 rounded-2xl border border-slate-100 group">
              <div className="flex items-center gap-4">
                <img src={m.avatar} className="w-10 h-10 rounded-full shadow-md border-2 border-white" alt="" />
                <div className="flex flex-col">
                  <span className="font-black text-slate-700 text-base">{m.name}</span>
                  <span className="text-[9px] text-slate-400 font-bold italic">যোগদান: {m.joinDate === 0 ? 'শুরু থেকে' : new Date(m.joinDate).toLocaleDateString('bn-BD')}</span>
                </div>
              </div>
              <button 
                onClick={() => removeMember(m.id)} 
                className="flex items-center gap-1 text-rose-500 text-[10px] font-black uppercase bg-rose-50 px-4 py-2 rounded-xl border border-rose-100 transition-all opacity-100"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
                ডিলিট
              </button>
            </div>
          ))}
        </div>
      </div>
      
      <div className="bg-amber-50 rounded-3xl p-6 border border-amber-100 shadow-sm shadow-amber-50">
        <h4 className="text-amber-800 font-black mb-2 flex items-center gap-2 text-sm justify-center">
          📅 যোগদান ভিত্তিক হিসাব
        </h4>
        <p className="text-amber-700 text-[11px] leading-relaxed font-bold text-center">
          নতুন মেম্বার যোগ হওয়ার আগের কোনো খরচ তার ওপর পড়বে না। সে যেদিন থেকে মেসে যোগদান করবে, কেবল সেই দিন থেকে হওয়া বাজার খরচগুলো তার ভাগে যোগ হবে।
        </p>
      </div>

      <p className="text-center text-slate-300 text-[9px] font-black uppercase tracking-[0.3em] mt-10">ডিজাইন ও ডেভেলপমেন্ট: বিল্লাল জামালপুর</p>
    </div>
  );

  const getContent = () => {
    switch(activeTab) {
      case 'dashboard': return renderDashboard();
      case 'expenses': return renderAddExpense();
      case 'history': return renderHistory();
      case 'summary': return renderSummary();
      default: return renderDashboard();
    }
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
      <div className="animate-fade-in px-1">
        {getContent()}
      </div>
    </Layout>
  );
};

export default App;
